#ifndef _events_h
#define _events_h
#include "stm32f10x.h"

void ReleaseEvents(void);
void StartShot(void); // generate pulse

#endif
