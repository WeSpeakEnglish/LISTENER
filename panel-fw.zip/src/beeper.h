#ifndef _beeper_h
#define _beeper_h
#include "stm32f10x.h"
void BeeperOn(u8 Beep);

#endif
