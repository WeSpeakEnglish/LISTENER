#ifndef _dac_h
#define _dac_h

void ConfigureDAC1(void);

#endif