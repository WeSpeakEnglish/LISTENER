#ifndef _timingconfig_h
#define _timingconfig_h

void ClockInit(void);


#endif